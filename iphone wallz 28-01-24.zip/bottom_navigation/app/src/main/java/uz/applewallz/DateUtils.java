package uz.applewallz;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

    public static String addTwoDays(String inputDateTime) throws ParseException {
        // Define the date format
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        // Parse the input string to a Date object
        Date date = dateFormat.parse(inputDateTime);

        // Add two days to the Date object
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, 2);

        // Format the result back to 'yyyy-MM-dd HH:mm:ss'

        return dateFormat.format(calendar.getTime());
    }

    public static String getCurrentTime() {
        // Define the date format
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        // Get the current date and time
        Date currentDate = new Date();

        // Format the current date and time to 'yyyy-MM-dd HH:mm:ss'

        return dateFormat.format(currentDate);
    }

    public static String getTimeDifference(String startDateStr, String endDateStr) {
        // Define the date format
        try
        {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            // Parse the input strings to Date objects
            Date startDate = dateFormat.parse(startDateStr);
            Date endDate = dateFormat.parse(endDateStr);

            // Calculate the time difference in milliseconds
            long timeDifferenceMillis = endDate.getTime() - startDate.getTime();

            // Calculate days, hours, minutes, and seconds
            long days = timeDifferenceMillis / (1000 * 60 * 60 * 24);
            long hours = (timeDifferenceMillis % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);
            long minutes = (timeDifferenceMillis % (1000 * 60 * 60)) / (1000 * 60);
            long seconds = (timeDifferenceMillis % (1000 * 60)) / 1000;

            // Format the result

            return days+"days ::"+hours+"hr  ::"+minutes+"min";
        }catch (Exception e)
        {
            return  null;
        }



    }

}
