package uz.applewallz.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Timer;
import java.util.TimerTask;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;
import uz.applewallz.R;
import uz.applewallz.Util;
import uz.applewallz.frags.Fragment_fav;
import uz.applewallz.frags.Fragment_home;
import uz.applewallz.frags.Fragment_wallz_store;


public class MainActivity extends  AppCompatActivity  { 
	
	
//	private ViewPager viewpager1;
	private BottomNavigationView bottomnavigation1;
	BlurView blurView;



	Fragment_home fragment1 = new Fragment_home();
	Fragment_wallz_store fragment2 = new Fragment_wallz_store();
	Fragment_fav fragment3 = new Fragment_fav();
	Fragment active = fragment1;
	final FragmentManager fm = getSupportFragmentManager();

	private AdView mAdView;

	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);

		MobileAds.initialize(this, new OnInitializationCompleteListener() {
			@Override
			public void onInitializationComplete(InitializationStatus initializationStatus) {



			}
		});
		mAdView = findViewById(R.id.adView);






		fm.beginTransaction().add(R.id.frame_layout, fragment3, "3").hide(fragment3).commit();
		fm.beginTransaction().add(R.id.frame_layout, fragment2, "2").hide(fragment2).commit();
		fm.beginTransaction().add(R.id.frame_layout,fragment1, "1").commit();


		initialize();
		initializeLogic();
	}

	@Override
	protected void onResume() {


		super.onResume();
	}

	@Override
	public void onBackPressed() {

		SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
		/*final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
		myEdit.putString("rate","true");
		myEdit.apply();*/
if(!sharedPreferences2.getString("rate","").equals("true"))
{
	cus_rate("https://play.google.com/store/apps/details?id="+getPackageName());
}else {

	finishAffinity();
}

	}


	private void cus_rate(String open_link) {
		try {
			final androidx.appcompat.app.AlertDialog dialog3 = new androidx.appcompat.app.AlertDialog.Builder(getApplicationContext()).create();
			View inflate = getLayoutInflater().inflate(R.layout.rating,null);

			dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
			dialog3.setView(inflate);


			final TextView rate = inflate.findViewById(R.id.rate);
			final TextView later = inflate.findViewById(R.id.later);


			BlurView blurView = inflate.findViewById(R.id.blurView);
			float radius = 14f;
			View decorView = getWindow().getDecorView();
			ViewGroup rootView = decorView.findViewById(android.R.id.content);
			Drawable windowBackground = decorView.getBackground();
			blurView.setupWith(rootView, new RenderScriptBlur(MainActivity.this)) // or RenderEffectBlur
					.setFrameClearDrawable(windowBackground) // Optional
					.setBlurRadius(radius);




			dialog3.setCancelable(true);



			later.setOnClickListener(view -> {

           /* Intent in = new Intent();
            in.setClass(getApplicationContext(),ShowWallz.class);
            // in.putExtra("rate","true");
            startActivity(in);*/
				finish();
			});


			rate.setOnClickListener(_view -> {
				if(!open_link.equals("")){

					Util.showToast("Thank you ♥", MainActivity.this);

					//it will rest the drop date after user click the

					// rate us button
					SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
					final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
					myEdit.putString("rate","true");
					myEdit.apply();


					Intent in = new Intent();
					in.setAction(Intent.ACTION_VIEW);
					in.setData(Uri.parse(open_link));
					startActivity(in);
					finish();



					dialog3.dismiss();
				}

			});
			dialog3.show();
		}catch (Exception e)
		{
finish();
		}

	}

	private void initialize() {


		SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
		if(sharedPreferences2.getString("premium","").equals("false")) {

			loadBannerAd(mAdView);
			Log.d("AD2123","HOME AD SHOWING");

		}else {
			Log.d("AD2123","HOME AD NOT SHOWING");
		}



		//viewpager1 = findViewById(R.id.viewpager1);
		bottomnavigation1 = findViewById(R.id.bottomnavigation1);



		blurView = findViewById(R.id.blurView);
		float radius = 16f;

		View decorView = getWindow().getDecorView();
		ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);

		Drawable windowBackground = decorView.getBackground();

		blurView.setupWith(rootView, new RenderScriptBlur(this)) // or RenderEffectBlur
				.setFrameClearDrawable(windowBackground) // Optional
				.setBlurRadius(radius);


		Window w = getWindow(); // in Activity's onCreate() for instance
		w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
				WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);


	/*	Fragment_home fragment = new Fragment_home();
		FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
		fragmentTransaction.replace(R.id.frame_layout, fragment, "");
		fragmentTransaction.commit();
*/

		fm.beginTransaction().hide(active).show(fragment1).commit();
		active = fragment1;


		bottomnavigation1.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(@NonNull MenuItem item) {
				//viewpager1.setCurrentItem((int)_itemId);
				bottomnavigation1.getMenu().getItem(item.getItemId()).setChecked(true);
				switch (item.getItemId())
				{
					case 0 :


						fm.beginTransaction().hide(active).show(fragment1).commit();
						active = fragment1;


						/*FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
						fragmentTransaction.replace(R.id.frame_layout, fragment, "");

						fragmentTransaction.commit();*/

						break;

					case 1 :

						fm.beginTransaction().hide(active).show(fragment2).commit();
						active = fragment2;
/*
						FragmentTransaction fragmentTransaction1 = getSupportFragmentManager().beginTransaction();
						fragmentTransaction1.replace(R.id.frame_layout, fragment1, "");

						fragmentTransaction1.commit();*/

						break;

					case 2 :

						fm.beginTransaction().hide(active).show(fragment3).commit();
						active = fragment3;

						/*FragmentTransaction fragmentTransaction2 = getSupportFragmentManager().beginTransaction();
						fragmentTransaction2.replace(R.id.frame_layout, fragment2, "");

						fragmentTransaction2.commit();*/

						break;
				}

				return false;
			}
		});
	}
	
	private void initializeLogic() {


		bottomnavigation1.getMenu().add(0, 0, 0, "Home").setIcon(R.drawable.ic_home_grey);
		bottomnavigation1.getMenu().add(0, 1, 0, "Wallz Store").setIcon(R.drawable.ic_filter_hdr_grey);
		bottomnavigation1.getMenu().add(0, 2, 0, "Favs").setIcon(R.drawable.anim_settings);
		bottomnavigation1.getMenu().getItem(0).setChecked(true);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);

	}
	

	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	void loadBannerAd(AdView adView){



		AdRequest adRequest = new AdRequest.Builder().build();
		adView.loadAd(adRequest);

		adView.setAdListener(new AdListener() {
			@Override
			public void onAdClicked() {
				// Code to be executed when the user clicks on an ad.
			}

			@Override
			public void onAdClosed() {
				// Code to be executed when the user is about to return
				// to the app after tapping on an ad.
			}

			@Override
			public void onAdFailedToLoad(LoadAdError adError) {
				adView.setVisibility(View.GONE);
				Log.d("AD2123", adError.getMessage());
				// Code to be executed when an ad request fails.
			}

			@Override
			public void onAdImpression() {
				// Code to be executed when an impression is recorded
				// for an ad.
			}

			@Override
			public void onAdLoaded() {
				Log.d("AD2123", "BANNER AD LOADED");
				// Code to be executed when an ad finishes loading.
			}

			@Override
			public void onAdOpened() {
				// Code to be executed when an ad opens an overlay that
				// covers the screen.
			}
		});

	}


}
